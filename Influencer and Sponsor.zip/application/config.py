class Config:
    SECRET_KEY = 'Will be filled in at a later stage'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///database.sqlite3'
    SQLALCHEMY_TRACT_MODIFICATIONS = False

    Debug = True